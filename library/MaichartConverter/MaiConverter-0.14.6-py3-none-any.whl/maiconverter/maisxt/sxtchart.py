from enum import Enum, auto


class SxtChartType(Enum):
    SRT = auto()
    SZT = auto()
    SCT = auto()
    SDT = auto()
