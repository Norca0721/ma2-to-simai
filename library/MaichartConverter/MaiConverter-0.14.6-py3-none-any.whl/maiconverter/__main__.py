from maiconverter.cli import main

main()
